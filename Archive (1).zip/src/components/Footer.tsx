import Link from "next/link";

const quickLinks = [
  { label: "Clinical Workshops", href: "/praxis" },
  { label: "Georgia & Kyrgyzstan", href: "/destinations" },
  { label: "Our Services", href: "/services" },
  { label: "Contact Us", href: "/contact" },
];

const programs = [
  { label: "INCREDOC Workshops", href: "/praxis" },
  { label: "MBBS in Georgia", href: "/destinations" },
  { label: "MBBS in Kyrgyzstan", href: "/destinations" },
  { label: "Accommodation Services", href: "/services" },
];

export default function Footer() {
  return (
    <footer className="bg-[#0B1A35] pt-16 pb-8 text-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Main 4-column grid */}
        <div className="grid grid-cols-1 gap-10 md:grid-cols-2 lg:grid-cols-4">
          {/* Column 1 — Company Info */}
          <div>
            <h3 className="font-playfair text-xl font-bold text-[#C6962E]">
              ABHA Global Educare
            </h3>
            <ul className="mt-4 space-y-1 text-sm text-white/70">
              <li>
                <span className="font-semibold text-white/90">Reg No:</span>{" "}
                ACO-8092
              </li>
            </ul>
            <p className="mt-4 text-sm italic text-[#C6962E]/90">
              &ldquo;Your Complete India + Georgia + Kyrgyzstan Support
              Partner&rdquo;
            </p>
          </div>

          {/* Column 2 — Quick Links */}
          <div>
            <h3 className="font-playfair text-lg font-bold text-[#C6962E]">
              Quick Links
            </h3>
            <ul className="mt-4 space-y-2 text-sm">
              {quickLinks.map(({ label, href }) => (
                <li key={label}>
                  <Link
                    href={href}
                    className="text-white/70 transition-colors duration-200 hover:text-[#C6962E]"
                  >
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3 — Programs */}
          <div>
            <h3 className="font-playfair text-lg font-bold text-[#C6962E]">
              Programs
            </h3>
            <ul className="mt-4 space-y-2 text-sm">
              {programs.map(({ label, href }) => (
                <li key={label}>
                  <Link
                    href={href}
                    className="text-white/70 transition-colors duration-200 hover:text-[#C6962E]"
                  >
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 4 — Contact */}
          <div>
            <h3 className="font-playfair text-lg font-bold text-[#C6962E]">
              Contact
            </h3>
            <ul className="mt-4 space-y-3 text-sm">
              <li>
                <a
                  href="tel:+917620707088"
                  className="text-white/70 transition-colors duration-200 hover:text-[#C6962E]"
                >
                  +91 76207 07088{" "}
                  <span className="text-white/50">(Kolhapur)</span>
                </a>
              </li>
              <li>
                <a
                  href="tel:+917447552878"
                  className="text-white/70 transition-colors duration-200 hover:text-[#C6962E]"
                >
                  +91 74475 52878{" "}
                  <span className="text-white/50">(CSN)</span>
                </a>
              </li>
              <li>
                <a
                  href="mailto:info@abhaglobaleducare.com"
                  className="text-white/70 transition-colors duration-200 hover:text-[#C6962E]"
                >
                  info@abhaglobaleducare.com
                </a>
              </li>
              <li>
                <a
                  href="https://wa.me/917620707088"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-white/70 transition-colors duration-200 hover:text-[#C6962E]"
                >
                  {/* WhatsApp icon */}
                  <svg
                    className="h-4 w-4"
                    fill="currentColor"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                  >
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z" />
                  </svg>
                  WhatsApp Support
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Footer Bottom */}
        <div className="mt-12 border-t border-white/10 pt-6 text-center text-sm text-white/50">
          <p>
            &copy; 2026 ABHA Global Educare LLP. All Rights Reserved. |
            Designed with ❤️ for Global Medical Education
          </p>
        </div>
      </div>
    </footer>
  );
}
